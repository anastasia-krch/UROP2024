from ase import Atoms, Atom
from ase.io import read
from mace.calculators import mace_mp
import numpy as np
from ase.constraints import FixAtoms, FixBondLengths
from ase.optimize import BFGS


def calculate_energy_landscape(input_file, output_file, spacing=1.0):
    # Load the atomic structure (fullerene + water)
    atoms = read(input_file)

    # Define the water molecule (assumes first 3 atoms are water)
    hydrogen = atoms[:1]

    # Determine the bounding box of the fullerene (ignores first 3 water atoms)
    fulleroid = atoms[1:]
    min_corner = np.min(fulleroid.get_positions(), axis=0)
    max_corner = np.max(fulleroid.get_positions(), axis=0)

    # Expand the box a bit beyond the fulleroid structure
    margin = 3.0  # Adjust the margin as needed
    min_corner -= margin
    max_corner += margin

    # Define the grid points within the box where the water molecule will be placed
    x_range = np.arange(min_corner[0], max_corner[0], spacing)
    y_range = np.arange(min_corner[1], max_corner[1], spacing)
    z_range = np.arange(min_corner[2], max_corner[2], spacing)

    # Set up a calculator for potential energy (EMT is just an example)
    calc = mace_mp(model="medium", device="cuda", default_dtype="float32")
    fulleroid.set_calculator(calc)
    print(x_range, y_range, z_range)
    with open(output_file, 'w') as f:
        f.write("x y z PE\n")  # Header for the output file

        # Iterate over all grid points and calculate the potential energy
        for x in x_range:
            for y in y_range:
                for z in z_range:
                    # Copy the full atomic structure
                    atoms_copy = fulleroid.copy()

                    # Translate the water molecule to the new position
                    translated_water = hydrogen.copy()
                    translated_water.translate([x, y, z])
                    
                    # Combine the fulleroid with the translated water
                    combined = translated_water + atoms_copy 
                    combined.set_calculator(calc)
        
                    potential_energy = combined.get_potential_energy()

                    # Write the position and potential energy to the output file
                    f.write(f"{x} {y} {z} {potential_energy}\n")
                    print("done")

    print(f"Energy landscape data saved to {output_file}")

# Usage
input_file = 'new_initial.xyz'  # Replace with your actual file path
output_file = 'energy_landscape.dat'  # Output file for energy data
spacing = 0.5  # Adjust the grid spacing as needed

calculate_energy_landscape(input_file, output_file, spacing)
