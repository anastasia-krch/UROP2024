#!/bin/bash

IPI=i-pi
PYTHON=python

# Get the driver name from the argument
driver=$1

# Define unique socket file
export IPI_SOCKET=/tmp/ipi_$driver

# Ensure no previous socket file exists
rm -f $IPI_SOCKET

# Update the input file with the correct driver address
sed -i "s|<address>.*</address>|<address>$driver</address>|" input.xml

echo "Starting i-PI with socket: $IPI_SOCKET"
${IPI} input.xml &> log.i-pi &

# Wait until the socket file is created or exit if timeout
timeout=120  # Increased timeout to 120 seconds
elapsed=0
while [ ! -S "$IPI_SOCKET" ]; do
    sleep 1
    elapsed=$((elapsed + 1))
    echo "Waiting for socket file $IPI_SOCKET... ($elapsed seconds elapsed)"
    if [ $elapsed -ge $timeout ]; then
        echo "Timeout waiting for socket file $IPI_SOCKET"
        rm -f $IPI_SOCKET
        pkill -P $$  # Kill all subprocesses
        exit 1
    fi
done

echo "Socket file $IPI_SOCKET created. Starting the Python script."

${PYTHON} run-mace.py $driver &

wait

# Clean up the socket file
rm -f $IPI_SOCKET
echo "Cleaned up socket file $IPI_SOCKET"
