import MDAnalysis as mda
from MDAnalysis.analysis.msd import EinsteinMSD
import numpy as np
from tqdm import tqdm

def analyze_diffusion(topology_file, trajectory_file, nanotube_atom_name='C', water_atom_name='O'):
    # Load the XYZ and EXTXYZ files with format specified
    u = mda.Universe(topology_file, trajectory_file, format='XYZ')

    # Select nanotube atoms (assuming they are named 'C')
    nanotube = u.select_atoms(f'name {nanotube_atom_name}')

    # Get the bounding box of the nanotube
    min_x, max_x = nanotube.positions[:, 0].min(), nanotube.positions[:, 0].max()
    min_y, max_y = nanotube.positions[:, 1].min(), nanotube.positions[:, 1].max()
    min_z, max_z = nanotube.positions[:, 2].min(), nanotube.positions[:, 2].max()

    # Print the bounding box of the nanotube
    print(f"Nanotube coordinates: x: [{min_x}, {max_x}], y: [{min_y}, {max_y}], z: [{min_z}, {max_z}]")

    # Select water molecules inside the nanotube bounding box
    initial_water = u.select_atoms(f'name {water_atom_name} and (prop x > {min_x} and prop x < {max_x}) and (prop y > {min_y} and prop y < {max_y}) and (prop z > {min_z} and prop z < {max_z})')
    
    # Tracking valid water molecules
    valid_indices = set(initial_water.indices)
    msd_values = []

    # Iterate over the trajectory with a progress bar
    for ts in tqdm(u.trajectory, desc="Processing Trajectory"):
        current_water = u.select_atoms(f'name {water_atom_name} and (prop x > {min_x} and prop x < {max_x}) and (prop y > {min_y} and prop y < {max_y}) and (prop z > {min_z} and prop z < {max_z})')
        current_indices = set(current_water.indices)
        valid_indices.intersection_update(current_indices)

        if not valid_indices:
            print("All water molecules have exited the nanotube.")
            break

        # Calculate MSD for valid water molecules
        valid_water = u.atoms[list(valid_indices)]
        msd_analysis = EinsteinMSD(valid_water, select='all', msd_type='xyz', fft=False)
        msd_analysis.run()
        msd_values.append(np.mean(msd_analysis.results.timeseries))

    # Time steps
    time_steps = np.arange(len(msd_values)) * u.trajectory.dt

    # Save MSD and time steps for later plotting
    np.savez('msd_data.npz', time_steps=time_steps, msd_values=msd_values)

    # Fit a line to the MSD data to get the slope
    valid_indices = ~np.isnan(msd_values)
    slope, intercept = np.polyfit(time_steps[valid_indices], msd_values[valid_indices], 1)
    diffusion_coefficient = slope / 6  # for 3D diffusion

    print(f"Diffusion coefficient: {diffusion_coefficient:.4e} nm^2/ps")

    return diffusion_coefficient

# Example usage
if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python script.py <topology_file> <trajectory_file>")
        sys.exit(1)

    topology_file = sys.argv[1]
    trajectory_file = sys.argv[2]
    analyze_diffusion(topology_file, trajectory_file)
